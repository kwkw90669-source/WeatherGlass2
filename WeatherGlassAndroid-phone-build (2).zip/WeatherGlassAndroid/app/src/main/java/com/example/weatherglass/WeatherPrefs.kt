package com.example.weatherglass

import android.content.Context

object WeatherPrefs {
    private const val FILE = "weather_settings"
    fun prefs(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    fun get(c: Context, key: String, fallback: String) = prefs(c).getString(key, fallback) ?: fallback
    fun save(c: Context, values: Map<String, String>) {
        val e = prefs(c).edit()
        values.forEach { (k, v) -> e.putString(k, v) }
        e.apply()
    }
}
