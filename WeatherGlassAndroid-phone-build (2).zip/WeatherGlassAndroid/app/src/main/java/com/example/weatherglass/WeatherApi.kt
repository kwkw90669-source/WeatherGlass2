package com.example.weatherglass

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class WeatherResult(
    val city: String, val temperature: Int, val code: Int, val rainChance: Int, val updated: String
)

object WeatherApi {
    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "WeatherGlassAndroid/1.0")
        return try {
            if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
            c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    fun fetch(cityName: String): WeatherResult {
        val q = URLEncoder.encode(cityName.ifBlank { "Köln" }, "UTF-8")
        val geo = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=ar&format=json"))
        val results = geo.optJSONArray("results") ?: throw Exception("لم يتم العثور على المدينة")
        if (results.length() == 0) throw Exception("لم يتم العثور على المدينة")
        val place = results.getJSONObject(0)
        val lat = place.getDouble("latitude")
        val lon = place.getDouble("longitude")
        val displayName = place.optString("name", cityName)
        val data = JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code,rain&hourly=precipitation_probability&forecast_days=1&timezone=auto"))
        val current = data.getJSONObject("current")
        val hourly = data.optJSONObject("hourly")
        val probs = hourly?.optJSONArray("precipitation_probability")
        val rain = if (probs != null && probs.length() > 0) probs.optInt(0, 0) else current.optDouble("rain", 0.0).toInt()
        val time = current.optString("time", "")
        return WeatherResult(displayName, current.optDouble("temperature_2m").toInt(),
            current.optInt("weather_code", 0), rain.coerceIn(0,100), time.replace('T',' '))
    }

    fun condition(code: Int): String = when (code) {
        0 -> "سماء صافية"
        1, 2 -> "غائم جزئيًا"
        3 -> "غائم"
        45, 48 -> "ضباب"
        in 51..57 -> "رذاذ"
        in 61..67 -> "أمطار"
        in 71..77 -> "ثلوج"
        in 80..82 -> "زخات مطر"
        in 85..86 -> "زخات ثلجية"
        in 95..99 -> "عواصف رعدية"
        else -> "حالة الطقس"
    }
    fun icon(code: Int): String = when (code) {
        0 -> "☀"
        1,2,3 -> "☁"
        in 51..67, in 80..82 -> "🌧"
        in 71..77, in 85..86 -> "❄"
        in 95..99 -> "⛈"
        else -> "🌤"
    }
}
