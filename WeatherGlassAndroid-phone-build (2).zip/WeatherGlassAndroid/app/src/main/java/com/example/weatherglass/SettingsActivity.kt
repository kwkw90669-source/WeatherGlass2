package com.example.weatherglass

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import java.util.concurrent.Executors

class SettingsActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var city: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        city = findViewById(R.id.city_input)
        status = findViewById(R.id.status_text)
        city.setText(WeatherPrefs.get(this, "city", "Köln"))
        select(R.id.color_group, WeatherPrefs.get(this,"color","blue"), mapOf("blue" to R.id.color_blue,"green" to R.id.color_green,"purple" to R.id.color_purple,"orange" to R.id.color_orange,"pink" to R.id.color_pink,"mono" to R.id.color_mono))
        select(R.id.style_group, WeatherPrefs.get(this,"style","glass"), mapOf("glass" to R.id.style_glass,"gradient" to R.id.style_gradient,"flat" to R.id.style_flat,"neon" to R.id.style_neon))
        select(R.id.theme_group, WeatherPrefs.get(this,"theme","dark"), mapOf("dark" to R.id.theme_dark,"light" to R.id.theme_light))
        select(R.id.corner_group, WeatherPrefs.get(this,"corner","round"), mapOf("round" to R.id.corner_round,"soft" to R.id.corner_soft,"square" to R.id.corner_square))
        findViewById<Button>(R.id.save_button).setOnClickListener {
            val colorId = findViewById<RadioGroup>(R.id.color_group).checkedRadioButtonId
            val styleId = findViewById<RadioGroup>(R.id.style_group).checkedRadioButtonId
            val themeId = findViewById<RadioGroup>(R.id.theme_group).checkedRadioButtonId
            val cornerId = findViewById<RadioGroup>(R.id.corner_group).checkedRadioButtonId
            WeatherPrefs.save(this, mapOf(
                "city" to city.text.toString().trim().ifBlank { "Köln" },
                "color" to mapOf(R.id.color_blue to "blue",R.id.color_green to "green",R.id.color_purple to "purple",R.id.color_orange to "orange",R.id.color_pink to "pink",R.id.color_mono to "mono")[colorId].orEmpty(),
                "style" to mapOf(R.id.style_glass to "glass",R.id.style_gradient to "gradient",R.id.style_flat to "flat",R.id.style_neon to "neon")[styleId].orEmpty(),
                "theme" to mapOf(R.id.theme_dark to "dark",R.id.theme_light to "light")[themeId].orEmpty(),
                "corner" to mapOf(R.id.corner_round to "round",R.id.corner_soft to "soft",R.id.corner_square to "square")[cornerId].orEmpty()
            ))
            refreshWidget()
            status.text = "تم حفظ الإعدادات. أضف أداة Weather Glass إلى الشاشة الرئيسية إن لم تكن موجودة."
        }
        findViewById<Button>(R.id.refresh_button).setOnClickListener { refreshWidget(); status.text = "جارٍ تحديث بيانات الطقس…" }
    }

    private fun select(groupId: Int, key: String, ids: Map<String, Int>) {
        findViewById<RadioGroup>(groupId).check(ids[key] ?: ids.values.first())
    }

    private fun refreshWidget() {
        val intent = Intent(this, WeatherWidgetProvider::class.java).apply { action = AppWidgetManager.ACTION_APPWIDGET_UPDATE }
        val ids = AppWidgetManager.getInstance(this).getAppWidgetIds(ComponentName(this, WeatherWidgetProvider::class.java))
        intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
        sendBroadcast(intent)
    }

    override fun onDestroy() { executor.shutdown(); super.onDestroy() }
}
