package com.example.weatherglass

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews
import java.util.concurrent.Executors

class WeatherWidgetProvider : AppWidgetProvider() {
    companion object {
        private val executor = Executors.newSingleThreadExecutor()
        private fun accent(color: String) = when(color) {
            "green" -> Color.rgb(101,237,131)
            "purple" -> Color.rgb(211,166,255)
            "orange" -> Color.rgb(255,192,120)
            "pink" -> Color.rgb(255,173,210)
            "mono" -> Color.WHITE
            else -> Color.rgb(125,232,250)
        }
        private fun base(color: String, light: Boolean): Int = if (light) Color.rgb(235,241,250) else when(color) {
            "green" -> Color.rgb(22,59,42)
            "purple" -> Color.rgb(69,44,112)
            "orange" -> Color.rgb(100,57,35)
            "pink" -> Color.rgb(105,56,79)
            "mono" -> Color.rgb(32,33,36)
            else -> Color.rgb(52,71,119)
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> showLoading(context, manager, id); fetchAndUpdate(context, manager, id) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == "com.example.weatherglass.REFRESH") {
            val manager = AppWidgetManager.getInstance(context)
            manager.getAppWidgetIds(ComponentName(context, WeatherWidgetProvider::class.java)).forEach {
                fetchAndUpdate(context, manager, it)
            }
        }
    }

    private fun showLoading(c: Context, m: AppWidgetManager, id: Int) {
        val v = makeViews(c, id)
        v.setTextViewText(R.id.widget_condition, "جارٍ تحديث الطقس…")
        m.updateAppWidget(id, v)
    }

    private fun fetchAndUpdate(c: Context, m: AppWidgetManager, id: Int) {
        executor.execute {
            try {
                val city = WeatherPrefs.get(c, "city", "Köln")
                val result = WeatherApi.fetch(city)
                val v = makeViews(c, id)
                v.setTextViewText(R.id.widget_city, result.city)
                v.setTextViewText(R.id.widget_temp, "${result.temperature}°")
                v.setTextViewText(R.id.widget_condition, WeatherApi.condition(result.code))
                v.setTextViewText(R.id.widget_icon, WeatherApi.icon(result.code))
                v.setTextViewText(R.id.widget_rain, "احتمال المطر: ${result.rainChance}%")
                v.setTextViewText(R.id.widget_updated, "آخر تحديث: ${result.updated}")
                m.updateAppWidget(id, v)
            } catch (e: Exception) {
                val v = makeViews(c, id)
                v.setTextViewText(R.id.widget_condition, "تعذر جلب الطقس. تحقق من الإنترنت أو اسم المدينة.")
                v.setTextViewText(R.id.widget_updated, "اضغط لفتح الإعدادات")
                m.updateAppWidget(id, v)
            }
        }
    }

    private fun makeViews(c: Context, id: Int): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_weather)
        val color = WeatherPrefs.get(c,"color","blue")
        val style = WeatherPrefs.get(c,"style","glass")
        val theme = WeatherPrefs.get(c,"theme","dark")
        val corner = WeatherPrefs.get(c,"corner","round")
        val light = theme == "light"
        // Select a real drawable resource so saved color/style/corner settings affect the home-screen widget.
        val drawableStyle = when (style) {
            "neon" -> "neon"
            "flat" -> "flat"
            else -> "glass" // gradient currently uses the glass base until a gradient-capable widget renderer is added
        }
        val drawableName = "bg_${if (color in listOf("blue","green","purple","orange","pink","mono")) color else "blue"}_${drawableStyle}_${if (corner in listOf("round","soft","square")) corner else "round"}"
        val drawableId = c.resources.getIdentifier(drawableName, "drawable", c.packageName)
        if (drawableId != 0) v.setInt(R.id.widget_root, "setBackgroundResource", drawableId)
        val fg = if (light) Color.rgb(28,37,55) else Color.WHITE
        v.setTextColor(R.id.widget_city, fg); v.setTextColor(R.id.widget_temp, fg); v.setTextColor(R.id.widget_condition, fg)
        v.setTextColor(R.id.widget_icon, accent(color)); v.setTextColor(R.id.widget_rain, accent(color))
        v.setTextColor(R.id.widget_updated, if(light) Color.DKGRAY else Color.LTGRAY)
        val open = PendingIntent.getActivity(c, 100 + id, Intent(c, SettingsActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        v.setOnClickPendingIntent(R.id.widget_root, open)
        val refresh = PendingIntent.getBroadcast(c, 200 + id, Intent(c, WeatherWidgetProvider::class.java).setAction("com.example.weatherglass.REFRESH"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        v.setOnClickPendingIntent(R.id.widget_icon, refresh)
        return v
    }

    private fun cornerRadius(corner: String) = when(corner) { "square" -> 4f; "soft" -> 18f; else -> 32f }
    private fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()
}
